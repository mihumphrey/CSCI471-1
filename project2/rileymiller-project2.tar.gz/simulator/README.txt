#
# This file should be updated with your name and any notes about your code.
#
Riley Miller
- Compile with Makefile
- run ./stressTest.pl and all tests should pass