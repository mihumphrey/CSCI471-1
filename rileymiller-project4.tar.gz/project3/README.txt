# Comments and instructions for the grader should go here.

Riley Miller

Just make the file and run the different outputs:

`./packetstats -f testfile.pcap -m -a -t -u -d 3`
