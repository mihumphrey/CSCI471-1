scp -r * rileymiller@isengard.mines.edu:~/code/csci471/project3
