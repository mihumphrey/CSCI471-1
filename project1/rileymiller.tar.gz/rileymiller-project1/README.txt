#Riley Miller, CSCI471 Project 1

To compile program type make.

To run verbose mode pass in the -v flag

To execute run `./web_server -v`

To quit program and kill server enter CTRL^C

To connect to the server use `http://isengard.mines.edu:<port_number>/<file_name>` to connect.

Everything works well for the most part. The only thing to note is that there's a bug with the way
my program reads in images so they appear cropped when served.


